import mod.client.extraClientApi as clientApi

Image, Label = clientApi.GetSystem("SAPI", "SAPI_C").getControls()