# -*- coding: utf-8 -*-
# from typing import List, Dict, Union


class EaseOptions(object):
    """"""


class CameraFadeOptions(object):
    """
    Used to initiate a full-screen color fade.
    """

    def __init__(self):
        pass


class CameraFixedBoomOptions(object):
    """"""
