from .subsystem import ClientSubsystem, SubsystemClient

@SubsystemClient
class ClientRemoteStore(ClientSubsystem):
    pass