# ModSAPI

<img src="pack_icon.png" width="300"/>

A library for Minecraft Netease Edition to create mod with SAPI style!

click [here](http://modsapi.pages.dev) to see the document
