
class Counter:

    def __init__(self):
        self.value = 0

    def add(self, value=1):
        self.value += value
